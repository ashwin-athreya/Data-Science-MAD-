package com.cg.mts.entities;

public class Seat {
private int seatId;
private String seatNumber;
private String type;
private double price;

}
