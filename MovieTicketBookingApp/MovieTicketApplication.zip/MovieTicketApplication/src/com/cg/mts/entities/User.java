package com.cg.mts.entities;

public class User {
private int userId;
private String password;
private String role;

}
