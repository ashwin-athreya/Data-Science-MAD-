package com.cg.mts.entities;

import java.util.List;

public class Ticket {
private int ticketId;
private int noOfSeats;
private List<String> seatNumber;
private Booking bookingRef;
private boolean ticketStatus;
private String screenName;


}
