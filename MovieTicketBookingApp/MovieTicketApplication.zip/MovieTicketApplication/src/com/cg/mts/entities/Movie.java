package com.cg.mts.entities;

public class Movie {

	private int movieId;
	private String movieName;
	private String movieGenre;
	private String movieHours;
	private String movieLanguage;
	private String movieDescription;
	
	
}
