package com.cg.mts.entities;

import java.util.List;

public class Theatre {
private int theatreId;
private String theatreName;
private String theatreCity;
private List<Movie> listOfMovies;
private List<Screen> listOfScreens;
private String managerName;
private String managerContact;

}
