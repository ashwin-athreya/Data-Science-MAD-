package com.cg.mts.exception;

public class MovieNotFoundException extends Exception {

}
