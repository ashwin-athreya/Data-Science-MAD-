package com.cg.mts.exception;

public class CustomerNotFoundException extends Exception {

}
