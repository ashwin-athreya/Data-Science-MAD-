package com.cg.mts.exception;

public class BookingNotFoundException extends Exception {

}
